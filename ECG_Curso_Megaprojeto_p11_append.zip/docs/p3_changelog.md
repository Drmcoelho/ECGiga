# Changelog p3 — 2025-09-25

- CLI: `ingest image` com suporte a META sidecar e geração de laudo no schema v0.1.
- Schema: `reporting/schema/report.schema.json`.
- Dash: upload/preview + sumarização de META (QTc/eixo se fornecidos).
- Amostras: ECG sintético 12-lead + META (calibração/medidas).
- Notebooks: pré-processamento básico e noções de detecção de grade.
- Quiz: +60 MCQs (posicionamento, marcapasso, canalopatias, armadilhas).
