# Changelog p5 — 2025-09-25

- **Deskew**: varredura de ângulo ±6° com maximização da variância de projeções de gradiente.
- **Normalização de escala**: px/mm alvo (10), clamp 0.5–2×.
- **Layouts**: segmentação para 3×4, 6×2 e 3×4+ritmo.
- **CLI**: novos comandos `cv deskew|normalize|layout-seg` e flags `--deskew/--normalize` na ingestão.
- **Dash**: switches para deskew/normalize e seletor de layout.
- **Notebooks**: 19–21 com demonstrações.
