# Dados & Fontes (p0)

- Repositórios educacionais open-source (ex.: LITFL ECG Library), PhysioNet (WFDB).
- Imagens com licença compatível (CC-BY/CC0). Atribua sempre que necessário.
- Em p1–p3 definiremos lista canônica de referências e créditos de imagens.
