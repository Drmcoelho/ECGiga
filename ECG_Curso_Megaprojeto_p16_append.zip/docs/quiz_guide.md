# Guia de Quiz (MCQ)

- Use `quiz/schema/mcq.schema.json` para validar consistência.
- Cada item precisa de **explicação robusta** e referência à seção do curso.
- Dificuldades: `easy|medium|hard`. Evite pegadinhas não clínicas.
- Use imagens quando agregarem (referencie em `images/`).
