# Changelog p2 — 2025-09-25

- CLI: `analyze values` (QTc Bazett/Fridericia, eixo I/aVF, flags educativas).
- Dash: adicionada calculadora QTc.
- Notebooks: 5 cadernos educativos.
- Quiz: +110 MCQs (p2) adicionados.
